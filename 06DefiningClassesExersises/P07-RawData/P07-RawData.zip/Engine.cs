﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P07_RawData
{
    public class Engine
    {
        public double speed;
        public double power;

        public Engine(double speed, double power)
        {
            this.speed = speed;
            this.power = power;
        }
    }
}
